An Example:

EAChecker.exe -p -c -s {4014B530-DD36-4fdb-8358-6005CF5FD9B2}